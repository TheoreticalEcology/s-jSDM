from .dense import Layer_dense
from .variational import Layer_dense_variational