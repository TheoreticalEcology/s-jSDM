library(testthat)
library(sjSDM)

test_check("sjSDM")
