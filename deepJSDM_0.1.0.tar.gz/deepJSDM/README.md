
# deepJSDM

<!-- badges: start -->
<!-- badges: end -->

The goal of deepJSDM is to ...

## Installation


```{r}
devtools::install_github("TheoreticalEcology/deepJSDM", subdir = "deepJSDM")
deepJSDM::install_install_pytorch()

```


## Example
```


```